package com.soft1851.user.center.dao;

import com.soft1851.user.center.domain.entity.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @ClassName
 * @Description TODO
 * @Author wanghuanle
 * @Date 2020/09/20
 **/
public interface UserMapper extends Mapper<User> {
}
